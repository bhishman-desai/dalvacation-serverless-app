const { SNSClient, ConfirmSubscriptionCommand } = require('@aws-sdk/client-sns');

const snsClient = new SNSClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    const { Token, TopicArn } = event.queryStringParameters;

    const params = {
        Token: Token,
        TopicArn: "arn:aws:sns:us-east-1:148182181402:DalVacation"
    };

    try {
        const command = new ConfirmSubscriptionCommand(params);
        await snsClient.send(command);

        return {
            statusCode: 200,
            body: 'Email subscription confirmed successfully!'
        };
    } catch (error) {
        console.error('Error confirming email subscription:', error);
        return {
            statusCode: 500,
            body: 'Failed to confirm email subscription.'
        };
    }
};
