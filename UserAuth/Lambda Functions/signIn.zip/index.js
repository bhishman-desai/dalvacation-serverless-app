const { CognitoIdentityProviderClient, InitiateAuthCommand } = require('@aws-sdk/client-cognito-identity-provider');

const client = new CognitoIdentityProviderClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    const { username, password } = event; // Assuming you receive the username and password

    const clientId = '4uiajssgcppev3k7effv8ti5f5';

    const params = {
        AuthFlow: 'USER_PASSWORD_AUTH',
        ClientId: clientId,
        AuthParameters: {
            USERNAME: username,
            PASSWORD: password
        }
    };

    try {
        const command = new InitiateAuthCommand(params);
        const response = await client.send(command);
        console.log(response);
        return {
            statusCode: 200,
            body:{
                message: 'User signed in successfully!',
                accessToken: response.AuthenticationResult.AccessToken,
                idToken: response.AuthenticationResult.IdToken,
                refreshToken: response.AuthenticationResult.RefreshToken
            },
        };
    } catch (error) {
        console.error('Error signing in user:', error);
        return {
            statusCode: 400,
            body: JSON.stringify(error.message),
        };
    }
};
