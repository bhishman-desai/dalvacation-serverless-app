const { CognitoIdentityProviderClient, SignUpCommand } = require('@aws-sdk/client-cognito-identity-provider');
const axios = require('axios');

const client = new CognitoIdentityProviderClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    const { password, username, email, role } = event;

    const params = {
        ClientId: '3asm0dioqbmn32lh0vie0lcecb',
        Username: email,
        Password: password,
        UserAttributes: [
            {
                Name: 'email',
                Value: email
            }
        ]
    };

    try {
        const command = new SignUpCommand(params);
        let response = await client.send(command);
        
        response = await axios.post('https://jmwefvfgih.execute-api.us-east-1.amazonaws.com/DalVacation/createTopic', { topicName: email.split('@')[0] });
        console.log(response.data);
        
        response = await axios.post('https://jmwefvfgih.execute-api.us-east-1.amazonaws.com/DalVacation/auth/subscribeEmail', { username: email });
        console.log(response.data);

        // response = await axios.post('https://jmwefvfgih.execute-api.us-east-1.amazonaws.com/DalVacation/auth/storeDetails', { username, email, role });
        // console.log(response.data);
        
        return {
            statusCode: 200,
            userId: "response.data.userId",
            message: {
                message: response.data,
                userId: "response.data.userId"
            },
        };
    } catch (error) {
        console.log(error)
        return {
            statusCode: 400,
            body: JSON.stringify(error.message),
        };
    }
};
