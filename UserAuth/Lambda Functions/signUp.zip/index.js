const { CognitoIdentityProviderClient, SignUpCommand } = require('@aws-sdk/client-cognito-identity-provider');
const axios = require('axios');

const client = new CognitoIdentityProviderClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    console.log(event)
    const { username, password, name, email, role } = event;

    const params = {
        ClientId: '4uiajssgcppev3k7effv8ti5f5',
        Username: username,
        Password: password,
        UserAttributes: [
            {
                Name: 'email',
                Value: username
            }
        ]
    };

    try {
        const command = new SignUpCommand(params);
        let response = await client.send(command);
        
        response = await axios.post('https://z5vur06rqi.execute-api.us-east-1.amazonaws.com/DalVacation/auth/SubscribeEmail', { username });
        console.log(response);
        
        response = await axios.post('https://g9l1t85jtf.execute-api.us-east-1.amazonaws.com/Test/store-details', { username, name, email, role });
        console.log(response);
        
        return {
            statusCode: 200,
            body: JSON.stringify('User registered successfully!'),
        };
    } catch (error) {
        console.log(error)
        return {
            statusCode: 400,
            body: JSON.stringify(error.message),
        };
    }
};
