const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-1' });
const ddbDocClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    const { username } = event;

    const params = {
        TableName: 'UserSecurityQuestions',
        Key: {
            username: username
        }
    };

    try {
        const command = new GetCommand(params);
        const response = await ddbDocClient.send(command);
        console.log(response.Item.key)
        return {
            statusCode: 200,
            body: response.Item.key,
        };
    } catch (error) {
        console.error('Error retrieving Key:', error);
        return {
            statusCode: 400,
            body: JSON.stringify(error.message),
        };
    }
};
