const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");

const dynamoDBClient = new DynamoDBClient({ region: 'us-east-1' }); 

exports.handler = async (event) => {
    const { email } = event;

    if (!email) {
        return {
            statusCode: 400,
            body: JSON.stringify('User ID is required in the request body.'),
        };
    }

    try {

        const getItemParams = {
            TableName: 'UserDetails',
            Key: {
                'email': { S: email } 
            }
        };

        const getItemCommand = new GetItemCommand(getItemParams);

        const { Item } = await dynamoDBClient.send(getItemCommand);

        if (!Item) {
            return {
                statusCode: 404,
                body: JSON.stringify('User not found.'),
            };
        }

        const user = {
            id: Item.id,
            username: Item.username,
            email: Item.email,
            role: Item.role,
        };

        return {
            statusCode: 200,
            body: user,
        };
    } catch (error) {
        console.error('Error retrieving user data:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Failed to retrieve user data.'),
        };
    }
};
