    const { DynamoDBClient, GetItemCommand, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");
const axios = require('axios');

const dynamoDBClient = new DynamoDBClient({ region: 'us-east-1' }); // Replace with your region

exports.handler = async (event) => {

    const { id, key } = event;
    
    if (!id || !key) {
        return {
            statusCode: 400,
            body: JSON.stringify('Both "username" and "key" fields are required in the request body.'),
        };
    }

    try {
        const getItemParams = {
            TableName: 'UserSecurityQuestions', // Replace with your DynamoDB table name
            Key: {
                'id': { N: id.toString() } // Assuming 'username' is the partition key
            }
        };
        

        const getItemCommand = new GetItemCommand(getItemParams);
        const { Item } = await dynamoDBClient.send(getItemCommand);

        if (!Item) {
            return {
                statusCode: 404,
                body: id,
            };
        }
        console.log(Item)

        const updateItemParams = {
        TableName: 'UserSecurityQuestions',
        Key: {
            'id': { N: id.toString() }
        },
        UpdateExpression: 'SET #keyAttr = :keyValue',
        ExpressionAttributeNames: {
            '#keyAttr': 'key'
        },
        ExpressionAttributeValues: {
            ':keyValue': { S: key.toString() } // Ensure key is converted to string
        }
    };


        const updateItemCommand = new UpdateItemCommand(updateItemParams);
        await dynamoDBClient.send(updateItemCommand);

        // const response = await axios.post('https://z5vur06rqi.execute-api.us-east-1.amazonaws.com/DalVacation/auth/confirmUser', { username });
        // console.log(response);

        return {
            statusCode: 200,
            body: 'Attribute "key" added successfully.',
        };
    } catch (error) {
        console.error('Error updating item:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Failed to update item.'),
        };
    }
};
