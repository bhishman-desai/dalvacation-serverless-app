const { CognitoIdentityProviderClient, AdminConfirmSignUpCommand } = require('@aws-sdk/client-cognito-identity-provider');

const client = new CognitoIdentityProviderClient({ region: 'us-east-1' });

exports.handler = async (event) => {
    const { username } = event; // Assuming you receive the username to confirm

    const clientId = "3asm0dioqbmn32lh0vie0lcecb";

    const params = {
        UserPoolId: "us-east-1_x1sxS2NLA",
        Username: username,
    };

    try {
        const command = new AdminConfirmSignUpCommand(params);
        const response = await client.send(command);
        console.log(response);
        return {
            statusCode: 200,
            body: JSON.stringify('User confirmed successfully!'),
        };
    } catch (error) {
        console.error('Error confirming user:', error);
        return {
            statusCode: 400,
            body: JSON.stringify(error.message),
        };
    }
};
