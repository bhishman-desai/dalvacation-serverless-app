const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-1' });
const ddbDocClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    const { username, answers, question } = event;

    const params = {
        TableName: 'UserSecurityQuestions',
        Item: {
            username: username,
            answers: answers,
            question: question
        }
    };

    try {
        const command = new PutCommand(params);
        await ddbDocClient.send(command);
        return {
            statusCode: 200,
            body: JSON.stringify('User security questions stored successfully!'),
        };
    } catch (error) {
        console.error('Error storing security questions:', error);
        return {
            statusCode: 400,
            body: JSON.stringify(error.message),
        };
    }
};
