const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-1' });
const ddbDocClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    const { username, name, email, role, password } = event;

    const params = {
        TableName: 'UserDetails',
        Item: {
            username: username,
            // mobile: mobile,
            name: name,
            email: email,
            role: role,
            password: password
        }
    };

    try {
        const command = new PutCommand(params);
        await ddbDocClient.send(command);
        return {
            statusCode: 200,
            body: 'User data stored successfully!',
            event
        };
    } catch (error) {
        console.error('Error storing user data:', error);
        return {
            statusCode: 400,
            body: error.message
        };
    }
};
