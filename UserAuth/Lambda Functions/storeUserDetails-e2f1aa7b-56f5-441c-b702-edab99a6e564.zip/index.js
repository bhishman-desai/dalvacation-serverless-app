const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-1' });
const ddbDocClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    const { username, email, role } = event;
    
    const id = Math.ceil(Math.random(1, 99999999)*999999999)

    const params = {
        TableName: 'UserDetails',
        Item: {
            id,
            username,
            // mobile: mobile,
            // name: name,
            email,
            role,
            // password: password
        }
    };

    try {
        const command = new PutCommand(params);
        await ddbDocClient.send(command);
        return {
            statusCode: 200,
            userId: id,
            body: 'User data stored successfully!',
            event
        };
    } catch (error) {
        console.error('Error storing user data:', error);
        return {
            statusCode: 400,
            body: error.message
        };
    }
};
