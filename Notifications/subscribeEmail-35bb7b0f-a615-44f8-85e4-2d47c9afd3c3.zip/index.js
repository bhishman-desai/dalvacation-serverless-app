const { SNSClient, SubscribeCommand } = require('@aws-sdk/client-sns');

const snsClient = new SNSClient({ region: 'us-east-1' });

const SNS_TOPIC_ARN = 'arn:aws:sns:us-east-1:148182181402:DalVacation';

exports.handler = async (event) => {
    const { username } = event;

    const params = {
        Protocol: 'email',
        TopicArn: 'arn:aws:sns:us-east-1:148182181402:'+username.split('@')[0],
        Endpoint: username
    };

    try {
        const command = new SubscribeCommand(params);
        await snsClient.send(command);

        return {
            statusCode: 200,
            body: 'Email subscribed to SNS topic successfully!'
        };
    } catch (error) {
        console.error('Error subscribing email to SNS topic:', error);
        return {
            statusCode: 500,
            body: 'Failed to subscribe email to SNS topic.',
        };
    }
};
