const { SNSClient, CreateTopicCommand } = require('@aws-sdk/client-sns');

exports.handler = async (event) => {

  const { topicName } = event || {}; 


  if (topicName && !topicName.trim()) {
    return {
      statusCode: 400,
      body: 'Topic name cannot be empty.',
    };
  }


  const snsClient = new SNSClient({ region: 'us-east-1' });

  const finalTopicName = topicName || 'MyLambdaTopic'; 

  try {

    const createTopicCommand = new CreateTopicCommand({ Name: finalTopicName });
    const data = await snsClient.send(createTopicCommand);

    return {
      statusCode: 200,
      body: `Topic created successfully! Topic ARN: ${data.TopicArn}`,
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      body: 'Error creating SNS topic: ' + err.message,
    };
  }
};
