const { SNSClient, PublishCommand } = require('@aws-sdk/client-sns');

exports.handler = async (event) => {

  const { email, body } = event;

  if (!email || !body) {
    return {
      statusCode: 400,
      body: 'Missing required fields: email and body',
    };
  }

  const snsClient = new SNSClient({ region: 'us-east-1' }); 

  const message = {
    Subject: 'Email Notification',
    Message: body,
    TopicArn: "arn:aws:sns:us-east-1:148182181402:"+email.split('@')[0], 
  };

  try {
    await snsClient.send(new PublishCommand(message));
    return {
      statusCode: 200,
      body: 'Email sent successfully!',
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      body: 'Error sending email: ' + err.message,
    };
  }
};