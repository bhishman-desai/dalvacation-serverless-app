const { SNSClient, SubscribeCommand } = require('@aws-sdk/client-sns');
const { GetSubscriptionAttributesCommand } = require("@aws-sdk/client-sns");

const snsClient = new SNSClient({ region: 'us-east-1' });

const SNS_TOPIC_ARN = 'arn:aws:sns:us-east-1:148182181402:DalVacation';

exports.handler = async (event) => {
    const { username } = event;

    const params = {
        Protocol: 'email',
        TopicArn: SNS_TOPIC_ARN,
        Endpoint: username
    };

    try {
        const command = new SubscribeCommand(params);
        const data = await snsClient.send(command);

        console.log(data)
        
        const isConfirmed = data.SubscriptionArn === "pending confirmation" ? false : true;
        return {
            statusCode: 200,
            body:{
                email: username,
                confirmed: isConfirmed
            },
        };
    } catch (error) {
        console.error('Error subscribing email to SNS topic:', error);
        return {
            statusCode: 500,
            body: 'Failed to subscribe email to SNS topic.',
        };
    }
};
